#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <stdlib.h>
#define  ； }
#define  ： void
#define ​ (：) {
#define ‌ () ;
#define ‍ ;
#define ⁠ *--_=
#define ⁡ (*--_).i=
#define ⁢ (*--_).s = 1+
#define ⁣ ={.e=&M[__COUNTER__]},
#define ⁤ T.i=
#define ﻿ (T.i);
#define  P (*_++)
#define  T (*_)
#define  O(o) t=P;T.i=T.i o t.i;
#define  DO {E I={.i=P.i};long i=P.i;for(;I.i<i;I.i++){
#define  LOOP }}
#define  LEAVE break;
#define  IF if(P.i){
#define  THEN }
#define  VARIABLES E
typedef  union E{double i;char*s;union E*e;}E;
E M[99],*_=M+50,*__=M+75,t;

： ＞R ​ *--__=P; ；
： R＞ ​ ⁠ *__++; ；
： ＋ ​ O(+) ；
： － ​ O(-) ；
： ＜ ​ O(<) ；
： ＊ ​ O(*) ；
： ／ ​ O(/) ；
： ＝ ​ O(==) ；
： ！ ​ *T.e=_[1];_+=2; ；
： ＠ ​ T=*T.e; ；
： DUP ​ _--; *_=_[1]; ；
： DROP ​ _++; ；
： OVER ​ t=_[1];⁠ t; ；
： ２DUP ​ OVER ‌ OVER ‌ ；
： SWAP ​ t=_[1];_[1]=*_;*_=t; ；
： EMIT ​ putchar ﻿ DROP ‌ ；
： ． ​ printf("%g",P.i); ；
： TYPE ​ fputs(P.s,stdout); ；

VARIABLES  u ⁣ v ⁣ j ⁣ U ⁣ V ⁣ X ⁣ Y ⁣ p ⁣ q ⁣ s ⁣ Q ⁣ K ‍

： S ​ ⁡ 59 ‍ EMIT ‌ ；

： L ​
   ⁢" \033[38;2;" ‍ TYPE ‌
   ． ‌ S ‌ ． ‌ S ‌ ． ‌
   ⁢" m\033[48;2;" ‍ TYPE ‌
   ． ‌ S ‌ ． ‌ S ‌ ． ‌
   ⁢" m▀\033[0m" ‍ TYPE ‌
；

： C ​ ⁤ cos ﻿ ⁡ 127 ‍ ＊ ‌ ⁡ 128 ‍ ＋ ‌ ⁤ trunc ﻿ ；

： c ​
  ⁡ .06283 ‍ ＊ ‌ ⁠ Q ‍ ＠ ‌ ＋ ‌ DUP ‌ DUP ‌ ＞R ‌ ＞R ‌
   C ‌
   R＞ ‌ ⁡ 2 ‍ ＋ ‌ C ‌
   R＞ ‌ ⁡ 4 ‍ ＋ ‌ C ‌
；

： m ​
  ⁠ V ‍ ！ ‌ ⁠ U ‍ ！ ‌
  ⁡ 0 ‍ DUP ‌ ⁠ u ‍ ！ ‌ ⁠ v ‍ ！ ‌
  ⁡ 100 ‍ DUP ‌ ⁠ j ‍ ！ ‌
  ⁡ 0 ‍ DO
     ⁠ u ‍ ＠ ‌ DUP ‌ ＊ ‌
     ⁠ v ‍ ＠ ‌ DUP ‌ ＊ ‌
      ２DUP ‌
      ＋ ‌ ⁡ 4 ‍ SWAP ‌ ＜ ‌ IF DROP ‌ DROP ‌ ⁠ I ‍ ⁠ j ‍ ！ ‌ LEAVE THEN
      － ‌ ⁠ U ‍ ＠ ‌ ＋ ‌
     ⁡ 2 ‍ ⁠ u ‍ ＠ ‌ ＊ ‌ ⁠ v ‍ ＠ ‌ ＊ ‌ ⁠ V ‍ ＠ ‌ ＋ ‌
     ⁠ v ‍ ！ ‌ ⁠ u ‍ ！ ‌
   LOOP
  ⁠ j ‍ ＠ ‌
；

： d ​ ⁠ p ‍ ＠ ‌ ＋ ‌ SWAP ‌ ⁠ q ‍ ＠ ‌ － ‌ SWAP ‌ ；

： l ​
  ⁠ X ‍ ＠ ‌ ⁡ 60 ‍ ⁠ p ‍ ＠ ‌ ＊ ‌ － ‌ ⁡ 40 ‍ ⁠ q ‍ ＠ ‌ ＊ ‌ ＋ ‌
  ⁠ Y ‍ ＠ ‌ ⁡ 40 ‍ ⁠ p ‍ ＠ ‌ ＊ ‌ － ‌ ⁡ 60 ‍ ⁠ q ‍ ＠ ‌ ＊ ‌ － ‌
  ⁡ 40 ‍ ⁡ 0 ‍ DO
      ２DUP ‌
     ⁡ 120 ‍ ⁡ 0 ‍ DO
         ２DUP ‌ m ‌ ＞R ‌
         ２DUP ‌ d ‌ m ‌
         c ‌ R＞ ‌ c ‌ L ‌
        ⁠ q ‍ ＠ ‌ ＋ ‌ SWAP ‌ ⁠ p ‍ ＠ ‌ ＋ ‌ SWAP ‌
      LOOP
      DROP ‌ DROP ‌
      d ‌ d ‌
     ⁡ 10 ‍ EMIT ‌
   LOOP
   DROP ‌ DROP ‌
；

： main ​
  ⁡-.74364388703715 ‍ ⁠ X ‍ ！ ‌
  ⁡ .13182590420533 ‍ ⁠ Y ‍ ！ ‌
  ⁡ 5 ‍ ⁠ s ‍ ！ ‌
   ⁢" \033[2J\033[H" ‍ TYPE ‌
  ⁡ 800 ‍ ⁡ 0 ‍ DO
     ⁠ s ‍ ＠ ‌ ⁠ Q ‍ ＠ ‌ ２DUP ‌
     ⁤ cos ﻿ ＊ ‌ ⁠ p ‍ ！ ‌
     ⁤ sin ﻿ ＊ ‌ ⁠ q ‍ ！ ‌
      ⁢" \033[H\033[?25l" ‍ TYPE ‌
      l ‌
      ⁢" \033[?25h" ‍ TYPE ‌
     ⁠ s ‍ ＠ ‌ ⁡ .97 ‍ ⁡ 400 ‍ ⁠ I ‍ ＜ ‌ ⁡ .06 ‍ ＊ ‌ ＋ ‌ ＊ ‌ ⁠ s ‍ ！ ‌
     ⁡ 16E3 ‍ usleep ﻿ DROP ‌
     ⁠ Q ‍ ＠ ‌ ⁡ .05 ‍ ＋ ‌ ⁠ Q ‍ ！ ‌
   LOOP
  ⁡ 0 ‍ exit ﻿
；
